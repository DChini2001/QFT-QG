# -*- coding: utf-8 -*-
"""
Created on Fri Jul  4 19:20:31 2025

@author: DEBABRATA CHINI
"""

import numpy as np
import matplotlib.pyplot as plt

# Parameters
num_nodes = 20
num_steps = 50
np.random.seed(10)

# Simulate node entropy (as background to drive curvature)
entropy = np.zeros((num_nodes, num_steps))
entropy[:, 0] = np.random.uniform(0.8, 2.0, size=num_nodes)

for t in range(1, num_steps):
    drift = 0.01 * (1 + np.sin(2 * np.pi * t / num_steps))
    noise = np.random.normal(0, 0.015, size=num_nodes)
    entropy[:, t] = entropy[:, t-1] + drift + noise
entropy = np.clip(entropy, 0, None)

# Compute curvature as time-varying divergence of entropy
curvature = np.zeros_like(entropy)
for t in range(1, num_steps-1):
    gradient = entropy[:, t+1] - entropy[:, t-1]
    local_var = np.var(entropy[:, max(0, t-2):t+2], axis=1)
    curvature[:, t] = 0.5 * gradient + 0.1 * local_var

# Plotting curvature over time
plt.figure(figsize=(10, 6))
for i in range(num_nodes):
    plt.plot(curvature[i], alpha=0.75, linewidth=1.3)

plt.title("Spatial Curvature Distribution Over Time", fontsize=14)
plt.xlabel("Time Step", fontsize=12)
plt.ylabel("Curvature $\\kappa_i(\\tau)$", fontsize=12)
plt.grid(True)
plt.tight_layout()
plt.show()
