# -*- coding: utf-8 -*-
"""
Created on Fri Jul  4 19:10:56 2025

@author: DEBABRATA CHINI
"""

import numpy as np
import matplotlib.pyplot as plt

# Parameters
num_nodes = 20
num_steps = 50
np.random.seed(42)

# Initialize entropy for each node
entropy = np.zeros((num_nodes, num_steps))
entropy[:, 0] = np.random.uniform(0.5, 1.5, size=num_nodes)

# Evolve entropy over time with drift and noise
for t in range(1, num_steps):
    drift = 0.015 + 0.005 * np.sin(2 * np.pi * t / num_steps)  # cyclic entropy drift
    noise = np.random.normal(0, 0.02, size=num_nodes)
    entropy[:, t] = entropy[:, t-1] + drift + noise

# Ensure no negative values
entropy = np.clip(entropy, 0, None)

# Plotting
plt.figure(figsize=(10, 6))
for i in range(num_nodes):
    plt.plot(entropy[i], label=f'Node {i}' if i < 5 else "", alpha=0.8, linewidth=1.2)

plt.title("Entropy Evolution Across Lattice Nodes", fontsize=14)
plt.xlabel("Time Step", fontsize=12)
plt.ylabel("Entropy $S_i(\\tau)$", fontsize=12)
plt.grid(True)
plt.tight_layout()
plt.show()
