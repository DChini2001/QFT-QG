# -*- coding: utf-8 -*-
"""
Created on Fri Jul  4 19:52:22 2025

@author: DEBABRATA CHINI
"""

import numpy as np
import matplotlib.pyplot as plt

# Parameters
num_nodes = 20
num_steps = 50
np.random.seed(52)

# Initialize field and entropy
phi = np.zeros((num_nodes, num_steps))
entropy = np.random.uniform(0.5, 2.0, size=num_nodes)

# Assign initial field values
phi[:, 0] = np.random.uniform(-1.0, 1.0, size=num_nodes)

# Define entropy gradient suppression coefficient per node
entropy_gradient = np.abs(np.gradient(entropy))
suppression_factor = np.exp(-2.0 * entropy_gradient)  # stronger gradient => more suppression

# Simulate field evolution with suppression
for t in range(1, num_steps):
    noise = np.random.normal(0, 0.05, size=num_nodes)
    decay = -0.1 * phi[:, t-1]  # damping
    flow = suppression_factor * (np.roll(phi[:, t-1], -1) - np.roll(phi[:, t-1], 1)) * 0.25
    phi[:, t] = phi[:, t-1] + decay + flow + noise

# Plotting
plt.figure(figsize=(10, 6))
for i in range(num_nodes):
    plt.plot(phi[i], linewidth=1.2, alpha=0.75)

plt.title("Gradient-Suppressed Field Flow Patterns", fontsize=14)
plt.xlabel("Time Step", fontsize=12)
plt.ylabel("Field Value $\\phi_i(\\tau)$", fontsize=12)
plt.grid(True)
plt.tight_layout()
plt.show()
