# -*- coding: utf-8 -*-
"""
Created on Fri Jul  4 19:47:23 2025

@author: DEBABRATA CHINI
"""

import numpy as np
import matplotlib.pyplot as plt

# Parameters
num_nodes = 20
num_steps = 50
np.random.seed(24)

# Simulate entropy flow into and out of each node
entropy_in = np.random.uniform(0.4, 1.0, size=(num_nodes, num_steps))
entropy_out = entropy_in + np.random.normal(0, 0.15, size=(num_nodes, num_steps))

# Compute irreversibility index I_i(t)
irreversibility_index = (entropy_out - entropy_in) ** 2

# Optional smoothing (rolling average)
for i in range(num_nodes):
    irreversibility_index[i] = np.convolve(irreversibility_index[i], np.ones(3)/3, mode='same')

# Plotting
plt.figure(figsize=(10, 6))
for i in range(num_nodes):
    plt.plot(irreversibility_index[i], alpha=0.75, linewidth=1.2)

plt.title("Irreversibility Index Fluctuation Per Node", fontsize=14)
plt.xlabel("Time Step", fontsize=12)
plt.ylabel("Irreversibility Index $\\mathcal{I}_i(\\tau)$", fontsize=12)
plt.grid(True)
plt.tight_layout()
plt.show()
