# -*- coding: utf-8 -*-
"""
Created on Fri Jul  4 16:16:06 2025

@author: DEBABRATA CHINI
"""

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
from mpl_toolkits.mplot3d import Axes3D

# Parameters
num_nodes = 20
radius = 0.5

# Create a random geometric graph (3D)
G = nx.random_geometric_graph(num_nodes, radius)
positions = {i: np.random.rand(3) * 10 for i in G.nodes()}

# Assign entropy to each node
entropy = {i: np.random.uniform(0.5, 2.5) for i in G.nodes()}
node_sizes = [100 * entropy[i] for i in G.nodes()]
colors = [(entropy[i] - min(entropy.values())) / (max(entropy.values()) - min(entropy.values())) for i in G.nodes()]

# Plot the 3D graph
fig = plt.figure(figsize=(9, 7))
ax = fig.add_subplot(111, projection='3d')

# Draw edges
for u, v in G.edges():
    x = [positions[u][0], positions[v][0]]
    y = [positions[u][1], positions[v][1]]
    z = [positions[u][2], positions[v][2]]
    ax.plot(x, y, z, color='gray', linewidth=1.2, alpha=0.7)

# Draw nodes
for idx, i in enumerate(G.nodes()):
    ax.scatter(*positions[i], s=node_sizes[idx], c=[[colors[idx], 0.2, 1 - colors[idx]]], alpha=0.9, edgecolors='k')

# Labels
ax.set_title("Model 1: Entropic Node Distribution in 3D Spacetime", fontsize=12)
ax.set_xlabel("X-axis")
ax.set_ylabel("Y-axis")
ax.set_zlabel("Z-axis")
plt.tight_layout()
plt.show()
