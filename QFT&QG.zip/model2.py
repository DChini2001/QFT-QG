# -*- coding: utf-8 -*-
"""
Created on Fri Jul  4 18:24:24 2025

@author: DEBABRATA CHINI
"""

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
from mpl_toolkits.mplot3d import Axes3D

# Parameters
num_nodes = 20
radius = 0.6

# Generate random geometric graph
G = nx.random_geometric_graph(num_nodes, radius)
positions = {i: np.random.rand(3) * 10 for i in G.nodes()}

# Define entropic curvature gradient per edge
curvature_gradient = {}
for u, v in G.edges():
    delta = np.linalg.norm(np.array(positions[u]) - np.array(positions[v]))
    curvature_gradient[(u, v)] = np.sin(delta) * np.random.uniform(0.5, 1.5)

# Normalize gradients for color mapping
values = list(curvature_gradient.values())
min_g, max_g = min(values), max(values)
normalized = {e: (v - min_g) / (max_g - min_g) for e, v in curvature_gradient.items()}

# Plotting 3D graph
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')

# Draw curvature-weighted edges
for (u, v), norm_val in normalized.items():
    x = [positions[u][0], positions[v][0]]
    y = [positions[u][1], positions[v][1]]
    z = [positions[u][2], positions[v][2]]
    color = (norm_val, 0.2, 1 - norm_val)  # Gradient from red to blue
    width = 1 + 2 * norm_val
    ax.plot(x, y, z, color=color, linewidth=width, alpha=0.8)

# Draw nodes
for i in G.nodes():
    ax.scatter(*positions[i], s=40, c='black')

# Labels
ax.set_title("Model 2: Curvature Gradient Propagation in Quantum Geometry", fontsize=12)
ax.set_xlabel("X-axis")
ax.set_ylabel("Y-axis")
ax.set_zlabel("Z-axis")
plt.tight_layout()
plt.show()
