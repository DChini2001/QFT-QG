# -*- coding: utf-8 -*-
"""
Created on Fri Jul  4 18:28:12 2025

@author: DEBABRATA CHINI
"""

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
from mpl_toolkits.mplot3d import Axes3D

# Parameters
num_nodes = 20
radius = 0.5

# Generate graph and node positions
G = nx.random_geometric_graph(num_nodes, radius)
positions = {i: np.random.rand(3) * 10 for i in G.nodes()}

# Assign entropy to nodes (to simulate imbalance)
entropy = {i: np.random.uniform(0.5, 3.0) for i in G.nodes()}

# Define directed entropy flow from lower to higher entropy
flow_edges = []
flow_weights = []
for u, v in G.edges():
    delta_S = entropy[v] - entropy[u]
    if delta_S > 0:
        flow_edges.append((u, v))
        flow_weights.append(delta_S)
    elif delta_S < 0:
        flow_edges.append((v, u))
        flow_weights.append(-delta_S)

# Normalize weights
max_weight = max(flow_weights) if flow_weights else 1
flow_weights = [w / max_weight for w in flow_weights]

# Plotting
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')

# Draw directional entropy flows
for idx, (u, v) in enumerate(flow_edges):
    x = [positions[u][0], positions[v][0]]
    y = [positions[u][1], positions[v][1]]
    z = [positions[u][2], positions[v][2]]
    color = (1 - flow_weights[idx], 0.3, flow_weights[idx])  # Blue to red
    ax.plot(x, y, z, color=color, linewidth=1 + 2 * flow_weights[idx], alpha=0.8)

# Draw nodes
for i in G.nodes():
    ax.scatter(*positions[i], s=50, c='black')
    ax.text(*positions[i], f"{entropy[i]:.1f}", fontsize=7, color='gray')

# Labels and layout
ax.set_title("Model 3: Irreversible Entropic Field Flow", fontsize=12)
ax.set_xlabel("X-axis")
ax.set_ylabel("Y-axis")
ax.set_zlabel("Z-axis")
plt.tight_layout()
plt.show()
