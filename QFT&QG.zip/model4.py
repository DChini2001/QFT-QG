# -*- coding: utf-8 -*-
"""
Created on Fri Jul  4 18:29:53 2025

@author: DEBABRATA CHINI
"""

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
from mpl_toolkits.mplot3d import Axes3D

# Parameters
num_nodes = 25
radius = 0.55

# Create a random geometric graph in 3D
G = nx.random_geometric_graph(num_nodes, radius)
positions = {i: np.random.rand(3) * 10 for i in G.nodes()}

# Identify hubs: assign higher entropy to a few core nodes
hub_nodes = np.random.choice(list(G.nodes()), size=4, replace=False)
entropy = {}
for node in G.nodes():
    if node in hub_nodes:
        entropy[node] = np.random.uniform(3.0, 5.0)  # High entropy hubs
    else:
        entropy[node] = np.random.uniform(0.5, 2.0)

# Size and color for plotting
node_sizes = [80 + 70 * entropy[i] for i in G.nodes()]
colors = [(entropy[i] - min(entropy.values())) / (max(entropy.values()) - min(entropy.values())) for i in G.nodes()]

# Plotting the lattice
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')

# Draw edges
for u, v in G.edges():
    x = [positions[u][0], positions[v][0]]
    y = [positions[u][1], positions[v][1]]
    z = [positions[u][2], positions[v][2]]
    ax.plot(x, y, z, color='gray', linewidth=1, alpha=0.5)

# Draw nodes with hub intensity
for idx, i in enumerate(G.nodes()):
    color = (colors[idx], 0.2, 1 - colors[idx])  # Blue to red scale
    ax.scatter(*positions[i], s=node_sizes[idx], c=[color], alpha=0.9, edgecolors='k')

# Labels and layout
ax.set_title("Model 4: Quantum Lattice with Information Hubs", fontsize=12)
ax.set_xlabel("X-axis")
ax.set_ylabel("Y-axis")
ax.set_zlabel("Z-axis")
plt.tight_layout()
plt.show()
