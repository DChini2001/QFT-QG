# -*- coding: utf-8 -*-
"""
Created on Fri Jul  4 18:31:55 2025

@author: DEBABRATA CHINI
"""

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import random

# Parameters
num_nodes = 25
initial_radius = 0.5

# Generate initial graph and node positions
G = nx.random_geometric_graph(num_nodes, initial_radius)
positions = {i: np.random.rand(3) * 10 for i in G.nodes()}

# Assign entropy values (simulate time-dependent fluctuation)
entropy = {i: np.random.uniform(0.5, 3.5) for i in G.nodes()}

# Rewire edges based on entropy-driven feedback (simulate deformation)
G_mod = nx.Graph()
G_mod.add_nodes_from(G.nodes())
for u, v in G.edges():
    e_diff = abs(entropy[u] - entropy[v])
    feedback_prob = np.exp(-e_diff)  # less entropy difference = more likely to preserve
    if random.random() < feedback_prob:
        G_mod.add_edge(u, v)

# Update edge list
edges = list(G_mod.edges())

# Normalize entropy for coloring
ent_values = list(entropy.values())
min_ent, max_ent = min(ent_values), max(ent_values)
colors = [(entropy[i] - min_ent) / (max_ent - min_ent) for i in G.nodes()]
sizes = [100 + 50 * colors[i] for i in range(len(colors))]

# Plotting
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')

# Draw updated edges
for u, v in edges:
    x = [positions[u][0], positions[v][0]]
    y = [positions[u][1], positions[v][1]]
    z = [positions[u][2], positions[v][2]]
    ax.plot(x, y, z, color='gray', alpha=0.6, linewidth=1.2)

# Draw entropy-deformed nodes
for idx, i in enumerate(G.nodes()):
    c_val = colors[idx]
    ax.scatter(*positions[i], s=sizes[idx], c=[(c_val, 0.3, 1 - c_val)], alpha=0.9, edgecolors='k')

# Labels and aesthetics
ax.set_title("Model 5: Topological Fluctuation with Entropic Feedback", fontsize=12)
ax.set_xlabel("X-axis")
ax.set_ylabel("Y-axis")
ax.set_zlabel("Z-axis")
plt.tight_layout()
plt.show()
