# -*- coding: utf-8 -*-
"""
Created on Fri Jul  4 20:04:40 2025

@author: DEBABRATA CHINI
"""

import numpy as np
import matplotlib.pyplot as plt

# Parameters
num_nodes = 20
num_steps = 50
np.random.seed(91)

# Initialize entropy and edge state matrix
entropy = np.random.uniform(0.5, 2.5, size=(num_nodes, num_steps))
edge_changes = np.zeros(num_steps)
entropic_stress = np.zeros(num_steps)

# Simulate entropy evolution and rewiring events
for t in range(1, num_steps):
    # Simulate entropy drift
    entropy[:, t] = entropy[:, t-1] + np.random.normal(0, 0.05, size=num_nodes)

    # Clip for realism
    entropy[:, t] = np.clip(entropy[:, t], 0.1, 5.0)

    # Compute entropic stress across random virtual edges
    stress_sum = 0
    edge_change_count = 0
    for _ in range(num_nodes):
        i, j = np.random.choice(num_nodes, size=2, replace=False)
        delta_s = abs(entropy[i, t] - entropy[j, t])
        stress_sum += delta_s

        # Edge rewiring probability increases with stress
        if np.random.rand() < min(1.0, 0.1 * delta_s):
            edge_change_count += 1

    # Record average stress and edge adaptation count
    entropic_stress[t] = stress_sum / num_nodes
    edge_changes[t] = edge_change_count

# Plotting
plt.figure(figsize=(10, 6))
plt.plot(entropic_stress, edge_changes, 'o-', linewidth=2, alpha=0.85)
plt.title("Topological Adaptation Frequency vs. Entropic Stress", fontsize=14)
plt.xlabel("Average Entropic Stress $\\langle |\\Delta S| \\rangle$", fontsize=12)
plt.ylabel("Edge Rewiring Frequency", fontsize=12)
plt.grid(True)
plt.tight_layout()
plt.show()
